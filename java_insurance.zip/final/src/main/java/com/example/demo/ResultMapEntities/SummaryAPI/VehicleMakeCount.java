package com.example.demo.ResultMapEntities.SummaryAPI;

import lombok.Data;

@Data
public class VehicleMakeCount {
    private String make;
    private int count;
}
