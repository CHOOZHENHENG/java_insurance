package com.example.demo.ResultMapEntities.SummaryAPI;

import lombok.Data;

@Data
public class ViolationPointPerDriver {
    /*private String driverID;*/
    private String idName;
    private int violationCount;
}
