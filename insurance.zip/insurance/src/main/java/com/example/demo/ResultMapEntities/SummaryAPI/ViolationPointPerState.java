package com.example.demo.ResultMapEntities.SummaryAPI;

import lombok.Data;

@Data
public class ViolationPointPerState {
    private String state;
    private int violationPoint;
}
